# Harbor AI Portal - Node 14 兼容版本

## 🎯 版本特点

这是Harbor AI Portal的Node 14兼容版本，专门为统一技术栈而重构：

### ✅ 技术栈统一
- **Node.js 兼容性**：支持Node 14+
- **构建工具**：使用Webpack 5替代Vite
- **包管理器**：使用npm替代pnpm
- **React版本**：降级到React 17以确保兼容性

### 🔧 核心功能保持不变
- **JSON配置驱动**：完全基于`src/data/content.json`配置
- **响应式设计**：支持桌面和移动设备
- **组件化架构**：模块化的React组件结构
- **Tailwind CSS**：现代化的样式框架

## 🌐 部署信息

**Node 14兼容版本**：https://faubpgvr.manus.space

## 🚀 开发环境要求

### 最低要求
- Node.js 14.0.0+
- npm 6.0.0+

### 推荐环境
- Node.js 16.x 或 18.x
- npm 8.x+

## 📦 项目结构

```
harbor-ai-portal-node14/
├── public/
│   └── index.html              # HTML模板
├── src/
│   ├── components/
│   │   ├── layout/             # 布局组件
│   │   ├── sections/           # 内容区块组件
│   │   └── ui/                 # UI组件
│   ├── data/
│   │   └── content.json        # 内容配置文件
│   ├── hooks/
│   │   └── useContent.js       # 内容加载Hook
│   ├── App.js                  # 主应用组件
│   ├── App.css                 # 应用样式
│   └── index.js                # 应用入口
├── webpack.config.js           # Webpack配置
├── tailwind.config.js          # Tailwind配置
├── postcss.config.js           # PostCSS配置
└── package.json                # 项目依赖
```

## 🛠️ 开发命令

### 安装依赖
```bash
npm install
```

### 启动开发服务器
```bash
npm run dev
# 或
npm start
```
开发服务器将在 http://localhost:3000 启动

### 构建生产版本
```bash
npm run build
```
构建文件将输出到 `dist/` 目录

### 代码检查
```bash
npm run lint
```

## 📝 内容管理

### 配置文件位置
`src/data/content.json`

### 更新流程
1. 修改 `src/data/content.json` 配置文件
2. 运行 `npm run build` 构建项目
3. 部署 `dist/` 目录到服务器

### 配置文件结构
```json
{
  "site": {
    "title": "Harbor AI Portal",
    "subtitle": "AI Community Resources"
  },
  "navigation": [
    { "name": "AI Tuesdays", "href": "#ai-tuesdays" }
  ],
  "banners": [
    {
      "id": 1,
      "icon": "🌞",
      "text": "Summer Series – Link to AI Tuesday Topic in Meetup",
      "link": "#ai-tuesdays",
      "bgColor": "bg-gradient-to-r from-yellow-400 to-orange-500"
    }
  ],
  "aiTuesdays": {
    "title": "AI Tuesdays",
    "description": ["段落1", "段落2"],
    "meetupLink": {
      "title": "AI Tuesdays Meetup",
      "description": "Connect with our community...",
      "url": "#ai-tuesdays-meetup"
    },
    "recordingsLink": {
      "title": "History Session Recordings",
      "description": "Access our archive...",
      "url": "#session-recordings"
    }
  },
  "footer": {
    "copyright": "© 2025 Harbor AI Platform",
    "description": "Empowering AI communities through collaboration and innovation"
  }
}
```

## 🔧 技术细节

### Webpack配置特点
- **开发服务器**：支持热重载和网络访问
- **生产构建**：代码分割和压缩优化
- **CSS处理**：PostCSS + Tailwind CSS
- **资源处理**：图片和字体文件处理

### React 17兼容性
- 使用 `ReactDOM.render()` 而非 `createRoot()`
- 兼容旧版本的React生态系统
- 支持类组件和函数组件

### 依赖管理
- **最小化依赖**：只包含必要的包
- **版本锁定**：确保构建一致性
- **安全更新**：定期更新安全补丁

## 🚀 部署指南

### 静态网站部署
1. 运行 `npm run build`
2. 将 `dist/` 目录内容上传到服务器
3. 配置服务器支持SPA路由（可选）

### Docker部署
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
FROM nginx:alpine
COPY --from=0 /app/dist /usr/share/nginx/html
```

### CI/CD集成
```yaml
# GitHub Actions示例
name: Build and Deploy
on:
  push:
    branches: [ main ]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - uses: actions/setup-node@v2
      with:
        node-version: '16'
    - run: npm ci
    - run: npm run build
    - run: npm run lint
```

## 🔍 故障排除

### 常见问题

1. **Node版本不兼容**
   ```bash
   # 检查Node版本
   node --version
   # 应该显示14.x或更高版本
   ```

2. **依赖安装失败**
   ```bash
   # 清理缓存重新安装
   npm cache clean --force
   rm -rf node_modules package-lock.json
   npm install
   ```

3. **构建失败**
   ```bash
   # 检查语法错误
   npm run lint
   # 查看详细错误信息
   npm run build --verbose
   ```

4. **样式不生效**
   - 确认Tailwind CSS配置正确
   - 检查PostCSS配置
   - 验证CSS导入路径

### 调试技巧
- 使用浏览器开发者工具检查控制台错误
- 检查网络请求是否正常
- 验证JSON配置文件格式

## 📞 技术支持

### 版本信息
- **项目版本**：v3.0 - Node 14兼容版
- **构建工具**：Webpack 5
- **React版本**：17.x
- **Node要求**：14+

### 联系方式
如需技术支持，请提供：
- Node.js版本信息
- 错误日志截图
- 修改的配置文件内容
- 浏览器和版本信息

---

**部署地址**：https://faubpgvr.manus.space
**更新日期**：2025年7月11日
**兼容性**：Node 14+ / npm 6+


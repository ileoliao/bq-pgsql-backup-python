import React from 'react';

const Button = ({ children, className = '', onClick, variant = 'primary', ...props }) => {
  const baseClasses = 'px-6 py-3 font-medium transition-all duration-300 shadow-sm hover:shadow-md rounded-xl';
  
  const variants = {
    primary: 'bg-blue-600 text-white hover:bg-blue-700',
    secondary: 'bg-green-600 text-white hover:bg-green-700',
    accent: 'bg-purple-600 text-white hover:bg-purple-700',
    outline: 'border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white',
    ghost: 'text-blue-600 hover:bg-blue-50'
  };
  
  return (
    <button
      className={`${baseClasses} ${variants[variant]} hover-lift ${className}`}
      onClick={onClick}
      {...props}
    >
      {children}
    </button>
  );
};

export { Button };


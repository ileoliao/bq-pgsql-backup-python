import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const PromotionBanner = () => {
  const { content } = useContent()
  const banners = content.banners
  const [currentBanner, setCurrentBanner] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length)
    }, 5000)

    return () => clearInterval(timer)
  }, [banners.length])

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length)
  }

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length)
  }

  const scrollToSection = (href) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  if (!banners || banners.length === 0) return null

  const banner = banners[currentBanner]

  // 预定义的背景样式映射
  const backgroundStyles = {
    1: 'bg-gradient-to-r from-yellow-400 to-orange-500',
    2: 'bg-gradient-to-r from-blue-500 to-purple-600'
  }

  const bannerBgClass = backgroundStyles[banner.id] || 'bg-gradient-to-r from-yellow-400 to-orange-500'

  return (
    <div className={`relative ${bannerBgClass} text-white py-3 overflow-hidden`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <button
            onClick={prevBanner}
            className="p-1 hover:bg-white/20 rounded-2xl transition-all duration-300"
            aria-label="Previous banner"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>

          <button
            onClick={() => scrollToSection(banner.link)}
            className="flex-1 text-center py-2 hover:bg-white/10 rounded-xl transition-all duration-300"
          >
            <span className="text-lg mr-2">{banner.icon}</span>
            <span className="font-medium">{banner.text}</span>
          </button>

          <button
            onClick={nextBanner}
            className="p-1 hover:bg-white/20 rounded-2xl transition-all duration-300"
            aria-label="Next banner"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Dots indicator */}
        {banners.length > 1 && (
          <div className="flex justify-center mt-2 space-x-2">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentBanner(index)}
                className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                  index === currentBanner ? 'bg-white' : 'bg-white/50'
                }`}
                aria-label={`Go to banner ${index + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default PromotionBanner


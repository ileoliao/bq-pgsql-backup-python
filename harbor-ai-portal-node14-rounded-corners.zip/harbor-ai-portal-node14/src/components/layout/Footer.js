import { useContent } from '../../hooks/useContent'

const Footer = () => {
  const { content } = useContent()
  const footer = content.footer

  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-lg">{footer.copyright}</p>
          <p className="text-gray-400 mt-2">
            {footer.description}
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer


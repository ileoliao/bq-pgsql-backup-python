import { BookOpen, ArrowRight } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const TrainingPathways = () => {
  const { content } = useContent()
  const training = content.trainingPathways

  return (
    <section id="training-pathways" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{training.title}</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Structured Learning */}
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg hover-lift transition-all duration-300">
            <div className="flex items-center mb-6">
              <BookOpen className="h-8 w-8 text-green-600 mr-4" />
              <h3 className="text-2xl font-bold text-gray-900">{training.cardTitle}</h3>
            </div>
            <p className="text-gray-700 mb-6 leading-relaxed">
              {training.cardDescription}
            </p>
            <button
              onClick={() => {
                console.log(`Navigate to ${training.trainingLink.url}`)
              }}
              className="inline-flex items-center bg-green-600 text-white py-3 px-6 rounded-xl font-medium hover:bg-green-700 transition-all duration-300 shadow-sm hover:shadow-md"
            >
              {training.trainingLink.title}
              <ArrowRight className="ml-2 h-4 w-4" />
            </button>
          </div>

          {/* Right side - Content */}
          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-gray-900">{training.subtitle}</h3>
            
            <div className="space-y-4">
              {training.description.map((paragraph, index) => (
                <p key={index} className="text-lg text-gray-700 leading-relaxed">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6 mt-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-green-600 mb-2">{training.stats.courses}</div>
                <div className="text-gray-600 font-medium">Courses Available</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-green-600 mb-2">{training.stats.students}</div>
                <div className="text-gray-600 font-medium">Students Trained</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default TrainingPathways


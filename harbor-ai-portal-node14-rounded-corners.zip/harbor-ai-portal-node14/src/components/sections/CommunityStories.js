import { FileText, ExternalLink } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const CommunityStories = () => {
  const { content } = useContent()
  const stories = content.communityStories

  // Category color mapping
  const categoryColors = {
    'Case Study': 'bg-blue-100 text-blue-800',
    'Personal Journey': 'bg-green-100 text-green-800',
    'Best Practices': 'bg-purple-100 text-purple-800',
    'Career': 'bg-orange-100 text-orange-800',
    'Strategy': 'bg-red-100 text-red-800',
    'Community': 'bg-teal-100 text-teal-800'
  }

  return (
    <section id="community-stories" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{stories.title}</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {stories.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stories.stories.map((article, index) => (
            <article key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover-lift transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-3 py-1 rounded-xl text-sm font-medium ${categoryColors[article.category] || 'bg-gray-100 text-gray-800'}`}>
                  {article.category}
                </span>
                <ExternalLink className="h-4 w-4 text-gray-400" />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-3 leading-tight">
                {article.title}
              </h3>
              
              <p className="text-gray-700 mb-4 leading-relaxed">
                {article.excerpt}
              </p>
              
              <div className="flex items-center justify-between text-sm text-gray-500">
                <span className="font-medium">{article.author}</span>
                <span>{article.date}</span>
              </div>
              
              <button
                onClick={() => {
                  console.log(`Navigate to ${article.link}`)
                }}
                className="mt-4 text-blue-600 font-medium hover:text-blue-700 transition-colors duration-200 inline-flex items-center"
              >
                Read Article
                <svg className="ml-1 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default CommunityStories


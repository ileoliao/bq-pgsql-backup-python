import { ExternalLink, Database, Users, FileText, Code, MessageCircle, HelpCircle } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const Links = () => {
  const { content } = useContent()
  const links = content.links

  return (
    <section id="links" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{links.title}</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {links.subtitle}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Categories */}
          {links.categories.map((category, index) => {
            const IconComponent = category.icon === 'Database' ? Database : Users
            const bgColor = category.color === 'bg-blue-500' ? 'bg-blue-600' : 'bg-green-600'
            const hoverColor = category.color === 'bg-blue-500' ? 'hover:bg-blue-700' : 'hover:bg-green-700'
            const lightBg = category.color === 'bg-blue-500' ? 'bg-blue-50' : 'bg-green-50'
            const lightHover = category.color === 'bg-blue-500' ? 'hover:bg-blue-100' : 'hover:bg-green-100'
            const iconColor = category.color === 'bg-blue-500' ? 'text-blue-600' : 'text-green-600'

            return (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg hover-lift transition-all duration-300">
                <div className="flex items-center mb-6">
                  <IconComponent className={`h-8 w-8 ${iconColor} mr-4`} />
                  <h3 className="text-2xl font-bold text-gray-900">{category.title}</h3>
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  {category.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {category.links.map((link, linkIndex) => {
                    const icons = {
                      'AI Tools Directory': FileText,
                      'Research Papers': FileText,
                      'Datasets Collection': Database,
                      'Code Repositories': Code,
                      'Global Ambassador Program': Users,
                      'Regional Networks': Users,
                      'Mentorship Program': Users,
                      'Partner Organizations': Users
                    }
                    const LinkIconComponent = icons[link.name] || FileText
                    
                    return (
                      <button
                        key={linkIndex}
                        onClick={() => console.log(`Navigate to ${link.url}`)}
                        className={`flex items-center p-3 text-left ${lightBg} rounded-xl ${lightHover} transition-all duration-300 shadow-sm hover:shadow-md`}
                      >
                        <LinkIconComponent className={`h-5 w-5 ${iconColor} mr-3`} />
                        <span className="text-sm font-medium text-gray-900">{link.name}</span>
                      </button>
                    )
                  })}
                </div>

                <button
                  onClick={() => console.log(`Navigate to main ${category.title} page`)}
                  className={`w-full ${bgColor} text-white py-3 px-6 rounded-xl font-medium ${hoverColor} transition-all duration-300 flex items-center justify-center shadow-sm hover:shadow-md`}
                >
                  Explore {category.title}
                  <ExternalLink className="ml-2 h-4 w-4" />
                </button>
              </div>
            )
          })}
        </div>

        {/* Quick Access */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Quick Access</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {links.quickAccess.map((item, index) => {
              const icons = {
                'Documentation': FileText,
                'API Reference': Code,
                'Community Forum': MessageCircle,
                'Support Center': HelpCircle
              }
              const IconComponent = icons[item] || FileText
              
              return (
                <button
                  key={index}
                  onClick={() => console.log(`Navigate to ${item}`)}
                  className="flex flex-col items-center p-4 bg-white rounded-2xl border border-gray-100 hover:shadow-lg hover-lift transition-all duration-300"
                >
                  <IconComponent className="h-6 w-6 text-gray-600 mb-2" />
                  <span className="text-sm font-medium text-gray-900">{item}</span>
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Links


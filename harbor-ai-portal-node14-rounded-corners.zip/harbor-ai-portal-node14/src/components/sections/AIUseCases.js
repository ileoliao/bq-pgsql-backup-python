import { Brain, Zap, Target, Lightbulb, Heart, Settings, Cpu, Globe } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const AIUseCases = () => {
  const { content } = useContent()
  const useCases = content.aiUseCases

  // Icon mapping with colors
  const iconMap = {
    'Brain': { icon: Brain, bgColor: 'bg-blue-500', textColor: 'text-white' },
    'Target': { icon: Target, bgColor: 'bg-green-500', textColor: 'text-white' },
    'Zap': { icon: Zap, bgColor: 'bg-purple-500', textColor: 'text-white' },
    'Cpu': { icon: Cpu, bgColor: 'bg-orange-500', textColor: 'text-white' },
    'Lightbulb': { icon: Lightbulb, bgColor: 'bg-pink-500', textColor: 'text-white' },
    'Globe': { icon: Globe, bgColor: 'bg-teal-500', textColor: 'text-white' },
    'Heart': { icon: Heart, bgColor: 'bg-red-500', textColor: 'text-white' },
    'Settings': { icon: Settings, bgColor: 'bg-indigo-500', textColor: 'text-white' }
  }

  return (
    <section id="ai-use-cases" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{useCases.title}</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {useCases.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {useCases.cases.map((useCase, index) => {
            const iconConfig = iconMap[useCase.icon] || iconMap['Brain']
            const IconComponent = iconConfig.icon

            return (
              <div key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover-lift transition-all duration-300">
                <div className="flex items-center mb-4">
                  <div className={`p-4 rounded-2xl ${iconConfig.bgColor} mr-4 shadow-sm`}>
                    <IconComponent className={`h-6 w-6 ${iconConfig.textColor}`} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{useCase.title}</h3>
                </div>
                <p className="text-gray-700 mb-4 leading-relaxed">
                  {useCase.description}
                </p>
                <button
                  onClick={() => {
                    console.log(`Navigate to ${useCase.link}`)
                  }}
                  className="text-blue-600 font-medium hover:text-blue-700 transition-colors duration-200 inline-flex items-center"
                >
                  Learn More
                  <svg className="ml-1 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default AIUseCases


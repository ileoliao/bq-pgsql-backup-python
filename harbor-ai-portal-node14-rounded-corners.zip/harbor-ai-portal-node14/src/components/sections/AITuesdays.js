import { Calendar, Video } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const AITuesdays = () => {
  const { content } = useContent()
  const aiTuesdays = content.aiTuesdays

  return (
    <section id="ai-tuesdays" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{aiTuesdays.title}</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left side - Description */}
          <div className="space-y-6">
            {aiTuesdays.description.map((paragraph, index) => (
              <p key={index} className="text-lg text-gray-700 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Right side - Action Cards */}
          <div className="space-y-6">
            {/* Join Our Meetup Card */}
            <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100 hover:shadow-lg hover-lift transition-all duration-300">
              <div className="flex items-center mb-4">
                <Calendar className="h-6 w-6 text-blue-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">{aiTuesdays.meetupLink.title}</h3>
              </div>
              <p className="text-gray-700 mb-4">
                {aiTuesdays.meetupLink.description}
              </p>
              <button
                onClick={() => {
                  console.log(`Navigate to ${aiTuesdays.meetupLink.url}`)
                }}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-xl font-medium hover:bg-blue-700 transition-all duration-300 shadow-sm hover:shadow-md"
              >
                AI Tuesdays Meetup
              </button>
            </div>

            {/* Session Recordings Card */}
            <div className="bg-purple-50 rounded-2xl p-6 border border-purple-100 hover:shadow-lg hover-lift transition-all duration-300">
              <div className="flex items-center mb-4">
                <Video className="h-6 w-6 text-purple-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">{aiTuesdays.recordingsLink.title}</h3>
              </div>
              <p className="text-gray-700 mb-4">
                {aiTuesdays.recordingsLink.description}
              </p>
              <button
                onClick={() => {
                  console.log(`Navigate to ${aiTuesdays.recordingsLink.url}`)
                }}
                className="w-full bg-purple-600 text-white py-3 px-6 rounded-xl font-medium hover:bg-purple-700 transition-all duration-300 shadow-sm hover:shadow-md"
              >
                History Session Recordings
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default AITuesdays


import { Users, Award, Heart } from 'lucide-react'
import { useContent } from '../../hooks/useContent'

const AboutUs = () => {
  const { content } = useContent()
  const aboutUs = content.aboutUs

  return (
    <section id="about-us" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{aboutUs.title}</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
        </div>

        {/* CCMS AI Community Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">{aboutUs.community.title}</h3>
            <div className="max-w-4xl mx-auto">
              {aboutUs.community.description.map((paragraph, index) => (
                <p key={index} className="text-lg text-gray-700 leading-relaxed mb-4">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">{aboutUs.community.stats.members}</div>
              <div className="text-gray-600 font-medium">Community Members</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">{aboutUs.community.stats.events}</div>
              <div className="text-gray-600 font-medium">Events Hosted</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">{aboutUs.community.stats.projects}</div>
              <div className="text-gray-600 font-medium">Active Projects</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">{aboutUs.community.stats.resources}</div>
              <div className="text-gray-600 font-medium">Learning Resources</div>
            </div>
          </div>
        </div>

        {/* Core Committee Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">{aboutUs.coreCommittee.title}</h3>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {aboutUs.coreCommittee.members.map((member, index) => {
              const initials = member.name.split(' ').map(n => n[0]).join('')
              return (
                <div key={index} className="text-center">
                  <div className="w-20 h-20 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-xl font-bold mx-auto mb-4 shadow-sm">
                    {initials}
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h4>
                  <p className="text-blue-600 font-medium mb-2">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.expertise}</p>
                </div>
              )
            })}
          </div>
        </div>

        {/* Sponsors Section */}
        <div>
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">{aboutUs.sponsors.title}</h3>
            <p className="text-lg text-gray-600">{aboutUs.sponsors.subtitle}</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
            {aboutUs.sponsors.list.map((sponsor, index) => {
              const initials = sponsor.split(' ').map(word => word[0]).join('').substring(0, 3)
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center text-gray-600 text-sm font-bold mx-auto mb-3 shadow-sm">
                    {initials}
                  </div>
                  <p className="text-sm font-medium text-gray-900">{sponsor}</p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}

export default AboutUs


import { useState, useEffect } from 'react'
import contentData from '../data/content.json'

export const useContent = () => {
  const [content, setContent] = useState(contentData)

  // 简化版本，只从JSON文件加载内容
  useEffect(() => {
    setContent(contentData)
  }, [])

  return {
    content
  }
}


import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

const PromotionBanner = () => {
  const [currentSlide, setCurrentSlide] = useState(0)

  const banners = [
    {
      id: 1,
      icon: '🌞',
      text: 'Summer Series – Link to AI Tuesday Topic in Meetup',
      link: '#ai-tuesdays',
      bgColor: 'bg-gradient-to-r from-yellow-400 to-orange-500'
    },
    {
      id: 2,
      icon: '📅',
      text: 'Next AI Tuesdays – Link to AI Tuesday Meetup',
      link: '#ai-tuesdays',
      bgColor: 'bg-gradient-to-r from-blue-500 to-purple-600'
    }
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length)
    }, 5000)

    return () => clearInterval(timer)
  }, [banners.length])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % banners.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length)
  }

  const scrollToSection = (href) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="relative overflow-hidden">
      <div 
        className={`${banners[currentSlide].bgColor} text-white py-4 transition-all duration-500`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={prevSlide}
              className="text-white hover:bg-white/20"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <div className="flex-1 text-center">
              <button
                onClick={() => scrollToSection(banners[currentSlide].link)}
                className="inline-flex items-center space-x-2 hover:underline transition-all duration-200"
              >
                <span className="text-2xl">{banners[currentSlide].icon}</span>
                <span className="text-lg font-medium">{banners[currentSlide].text}</span>
              </button>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={nextSlide}
              className="text-white hover:bg-white/20"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Dots indicator */}
          <div className="flex justify-center mt-2 space-x-2">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all duration-200 ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default PromotionBanner


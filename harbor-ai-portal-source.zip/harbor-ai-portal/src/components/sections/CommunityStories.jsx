import { FileText, ExternalLink } from 'lucide-react'

const CommunityStories = () => {
  const stories = [
    {
      id: 1,
      title: 'How AI Transformed Our Customer Service',
      author: 'Sarah Chen',
      date: 'January 15, 2025',
      excerpt: 'A deep dive into implementing chatbots and natural language processing to revolutionize customer support.',
      link: '#story-customer-service',
      category: 'Case Study'
    },
    {
      id: 2,
      title: 'Building My First Machine Learning Model',
      author: 'Michael Rodriguez',
      date: 'January 10, 2025',
      excerpt: 'A beginner\'s journey from zero to deploying a working ML model in production.',
      link: '#story-first-ml-model',
      category: 'Personal Journey'
    },
    {
      id: 3,
      title: 'AI Ethics in Practice: Lessons Learned',
      author: 'Dr. Emily Watson',
      date: 'January 8, 2025',
      excerpt: 'Exploring the challenges and solutions in implementing ethical AI practices in enterprise environments.',
      link: '#story-ai-ethics',
      category: 'Best Practices'
    },
    {
      id: 4,
      title: 'From Data Scientist to AI Product Manager',
      author: 'James Liu',
      date: 'January 5, 2025',
      excerpt: 'Career transition insights and the skills needed to bridge technical AI knowledge with product strategy.',
      link: '#story-career-transition',
      category: 'Career'
    },
    {
      id: 5,
      title: 'Scaling AI Solutions in Small Teams',
      author: 'Anna Kowalski',
      date: 'January 3, 2025',
      excerpt: 'Practical strategies for implementing AI solutions when resources are limited.',
      link: '#story-scaling-ai',
      category: 'Strategy'
    },
    {
      id: 6,
      title: 'Community Collaboration Success Story',
      author: 'Harbor AI Team',
      date: 'December 28, 2024',
      excerpt: 'How our community came together to solve a complex AI challenge through collaborative effort.',
      link: '#story-collaboration',
      category: 'Community'
    }
  ]

  const getCategoryColor = (category) => {
    const colors = {
      'Case Study': 'bg-blue-100 text-blue-800',
      'Personal Journey': 'bg-green-100 text-green-800',
      'Best Practices': 'bg-purple-100 text-purple-800',
      'Career': 'bg-orange-100 text-orange-800',
      'Strategy': 'bg-pink-100 text-pink-800',
      'Community': 'bg-teal-100 text-teal-800'
    }
    return colors[category] || 'bg-gray-100 text-gray-800'
  }

  return (
    <section id="community-stories" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Community Stories</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Read inspiring stories, insights, and experiences shared by our AI community members
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stories.map((story) => (
            <article
              key={story.id}
              className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300 cursor-pointer group"
              onClick={() => {
                // Placeholder link - would normally navigate to article
                console.log(`Navigate to ${story.link}`)
              }}
            >
              <div className="flex items-start justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(story.category)}`}>
                  {story.category}
                </span>
                <ExternalLink className="h-4 w-4 text-gray-400 group-hover:text-primary transition-colors duration-300" />
              </div>

              <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-primary transition-colors duration-300 line-clamp-2">
                {story.title}
              </h3>

              <p className="text-gray-700 mb-4 leading-relaxed line-clamp-3">
                {story.excerpt}
              </p>

              <div className="flex items-center justify-between text-sm text-gray-500">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  <span>{story.author}</span>
                </div>
                <span>{story.date}</span>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center text-primary font-medium group-hover:underline">
                  <span>Read Article</span>
                  <svg className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default CommunityStories


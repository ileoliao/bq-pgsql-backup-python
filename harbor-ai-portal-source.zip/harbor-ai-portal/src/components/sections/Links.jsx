import { ExternalLink, Database, Network } from 'lucide-react'
import { Button } from '@/components/ui/button'

const Links = () => {
  const linkCategories = [
    {
      title: 'Group AI – Resources',
      description: 'Access our comprehensive collection of AI tools, datasets, research papers, and learning materials.',
      icon: Database,
      color: 'bg-blue-500',
      links: [
        { name: 'AI Tools Directory', url: '#ai-tools' },
        { name: 'Research Papers', url: '#research-papers' },
        { name: 'Datasets Collection', url: '#datasets' },
        { name: 'Code Repositories', url: '#code-repos' }
      ]
    },
    {
      title: 'AI Ambassador Networks',
      description: 'Connect with AI ambassadors and regional networks to expand your professional circle.',
      icon: Network,
      color: 'bg-green-500',
      links: [
        { name: 'Global Ambassador Program', url: '#global-ambassadors' },
        { name: 'Regional Networks', url: '#regional-networks' },
        { name: 'Mentorship Program', url: '#mentorship' },
        { name: 'Partner Organizations', url: '#partners' }
      ]
    }
  ]

  return (
    <section id="links" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Links</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our curated collection of resources and connect with our extended network
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {linkCategories.map((category, index) => {
            const IconComponent = category.icon
            return (
              <div key={index} className="bg-white rounded-xl shadow-lg border border-gray-200 p-8">
                <div className="flex items-center mb-6">
                  <div className={`${category.color} p-3 rounded-lg mr-4`}>
                    <IconComponent className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">{category.title}</h3>
                </div>

                <p className="text-gray-700 mb-6 leading-relaxed">
                  {category.description}
                </p>

                <div className="space-y-3">
                  {category.links.map((link, linkIndex) => (
                    <Button
                      key={linkIndex}
                      variant="outline"
                      className="w-full justify-between text-left h-auto py-3 px-4 hover:bg-gray-50"
                      onClick={() => {
                        // Placeholder link - would normally navigate to actual URL
                        console.log(`Navigate to ${link.url}`)
                      }}
                    >
                      <span className="font-medium">{link.name}</span>
                      <ExternalLink className="h-4 w-4 text-gray-400" />
                    </Button>
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t border-gray-100">
                  <Button className={`w-full ${category.color} hover:opacity-90`}>
                    <span>Explore All Resources</span>
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            )
          })}
        </div>

        {/* Additional Quick Links */}
        <div className="mt-12 bg-white rounded-xl shadow-lg border border-gray-200 p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Quick Access</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              'Documentation',
              'API Reference',
              'Community Forum',
              'Support Center'
            ].map((item, index) => (
              <Button
                key={index}
                variant="ghost"
                className="h-auto py-4 px-4 flex flex-col items-center space-y-2 hover:bg-gray-50"
                onClick={() => {
                  console.log(`Navigate to ${item}`)
                }}
              >
                <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                  <ExternalLink className="h-6 w-6 text-gray-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">{item}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Links


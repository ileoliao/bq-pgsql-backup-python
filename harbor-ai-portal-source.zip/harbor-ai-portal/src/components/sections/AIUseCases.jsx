import { Brain, Zap, Target, Lightbulb, Cpu, Globe } from 'lucide-react'

const AIUseCases = () => {
  const useCases = [
    {
      id: 1,
      title: 'Natural Language Processing',
      description: 'Explore how AI transforms text analysis, chatbots, and language understanding.',
      icon: Brain,
      color: 'bg-blue-500',
      link: '#confluence-nlp'
    },
    {
      id: 2,
      title: 'Computer Vision',
      description: 'Discover AI applications in image recognition, object detection, and visual analysis.',
      icon: Target,
      color: 'bg-green-500',
      link: '#confluence-cv'
    },
    {
      id: 3,
      title: 'Predictive Analytics',
      description: 'Learn how AI predicts trends, behaviors, and outcomes across various industries.',
      icon: Zap,
      color: 'bg-purple-500',
      link: '#confluence-analytics'
    },
    {
      id: 4,
      title: 'Automation & Robotics',
      description: 'See how AI drives intelligent automation and robotic process optimization.',
      icon: Cpu,
      color: 'bg-orange-500',
      link: '#confluence-automation'
    },
    {
      id: 5,
      title: 'Recommendation Systems',
      description: 'Understand AI-powered personalization and recommendation algorithms.',
      icon: Lightbulb,
      color: 'bg-pink-500',
      link: '#confluence-recommendations'
    },
    {
      id: 6,
      title: 'AI in Healthcare',
      description: 'Explore revolutionary AI applications in medical diagnosis and treatment.',
      icon: Globe,
      color: 'bg-teal-500',
      link: '#confluence-healthcare'
    }
  ]

  return (
    <section id="ai-use-cases" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">AI Use Cases</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover real-world applications of artificial intelligence across different industries and domains
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {useCases.map((useCase) => {
            const IconComponent = useCase.icon
            return (
              <div
                key={useCase.id}
                className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-all duration-300 cursor-pointer group"
                onClick={() => {
                  // Placeholder link - would normally navigate to Confluence page
                  console.log(`Navigate to ${useCase.link}`)
                }}
              >
                <div className="flex items-center mb-4">
                  <div className={`${useCase.color} p-3 rounded-lg mr-4 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-primary transition-colors duration-300">
                    {useCase.title}
                  </h3>
                </div>
                <p className="text-gray-700 leading-relaxed mb-4">
                  {useCase.description}
                </p>
                <div className="flex items-center text-primary font-medium group-hover:underline">
                  <span>Learn More</span>
                  <svg className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default AIUseCases


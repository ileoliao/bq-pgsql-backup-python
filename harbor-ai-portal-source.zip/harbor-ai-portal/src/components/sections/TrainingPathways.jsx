import { BookOpen, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

const TrainingPathways = () => {
  return (
    <section id="training-pathways" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Training Pathways</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="bg-white p-8 rounded-xl shadow-lg border">
              <div className="flex items-center mb-6">
                <BookOpen className="h-8 w-8 text-green-600 mr-4" />
                <h3 className="text-2xl font-bold text-gray-900">Structured Learning</h3>
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">
                Discover comprehensive training programs designed to take you from AI fundamentals to advanced applications. 
                Our curated pathways provide step-by-step guidance for learners at every level.
              </p>
              <Button className="w-full bg-green-600 hover:bg-green-700 text-lg py-3">
                <span>Explore Training Website</span>
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>

          <div className="order-1 md:order-2">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              Accelerate Your AI Journey
            </h3>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Our training pathways are carefully crafted to provide you with practical skills and theoretical knowledge 
              needed to excel in the AI field. From machine learning basics to advanced deep learning techniques, 
              we offer structured learning experiences that adapt to your pace and goals.
            </p>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Whether you're looking to transition into AI, enhance your current skills, or stay updated with the latest 
              developments, our training programs provide the foundation you need for success.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-white rounded-lg shadow">
                <div className="text-3xl font-bold text-green-600 mb-2">50+</div>
                <div className="text-gray-700">Courses Available</div>
              </div>
              <div className="text-center p-4 bg-white rounded-lg shadow">
                <div className="text-3xl font-bold text-green-600 mb-2">1000+</div>
                <div className="text-gray-700">Students Trained</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default TrainingPathways


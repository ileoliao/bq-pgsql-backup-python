import { Users, Award, Heart } from 'lucide-react'

const AboutUs = () => {
  const teamMembers = [
    {
      name: 'Dr. Alex Thompson',
      role: 'Community Lead',
      expertise: 'Machine Learning & AI Strategy'
    },
    {
      name: 'Maria Garcia',
      role: 'Technical Director',
      expertise: 'Deep Learning & Computer Vision'
    },
    {
      name: 'David Kim',
      role: 'Education Coordinator',
      expertise: 'AI Training & Curriculum Development'
    },
    {
      name: 'Sophie Chen',
      role: 'Community Manager',
      expertise: 'Community Building & Events'
    }
  ]

  const sponsors = [
    'TechCorp Solutions',
    'AI Innovations Ltd',
    'DataFlow Systems',
    'Neural Networks Inc',
    'CloudAI Partners'
  ]

  return (
    <section id="about-us" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">About Us</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
        </div>

        {/* CCMS AI Community */}
        <div className="mb-16">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <Users className="h-8 w-8 text-blue-600 mr-4" />
                <h3 className="text-3xl font-bold text-gray-900">CCMS AI Community</h3>
              </div>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                The CCMS AI Community is a vibrant ecosystem of AI enthusiasts, researchers, practitioners, and learners 
                committed to advancing artificial intelligence through collaboration, education, and innovation.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Founded with the vision of democratizing AI knowledge, we bring together diverse perspectives to tackle 
                real-world challenges and foster the next generation of AI leaders.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-6 bg-blue-50 rounded-lg">
                <div className="text-4xl font-bold text-blue-600 mb-2">500+</div>
                <div className="text-gray-700">Active Members</div>
              </div>
              <div className="text-center p-6 bg-green-50 rounded-lg">
                <div className="text-4xl font-bold text-green-600 mb-2">50+</div>
                <div className="text-gray-700">Events Hosted</div>
              </div>
              <div className="text-center p-6 bg-purple-50 rounded-lg">
                <div className="text-4xl font-bold text-purple-600 mb-2">25+</div>
                <div className="text-gray-700">Projects Completed</div>
              </div>
              <div className="text-center p-6 bg-orange-50 rounded-lg">
                <div className="text-4xl font-bold text-orange-600 mb-2">100+</div>
                <div className="text-gray-700">Learning Resources</div>
              </div>
            </div>
          </div>
        </div>

        {/* Core Committee */}
        <div className="mb-16">
          <div className="flex items-center justify-center mb-8">
            <Award className="h-8 w-8 text-purple-600 mr-4" />
            <h3 className="text-3xl font-bold text-gray-900">Core Committee</h3>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="text-center bg-gray-50 p-6 rounded-lg">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-white text-xl font-bold">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h4>
                <p className="text-purple-600 font-medium mb-2">{member.role}</p>
                <p className="text-gray-600 text-sm">{member.expertise}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Sponsors */}
        <div>
          <div className="flex items-center justify-center mb-8">
            <Heart className="h-8 w-8 text-red-600 mr-4" />
            <h3 className="text-3xl font-bold text-gray-900">Our Sponsors</h3>
          </div>
          <p className="text-center text-lg text-gray-600 mb-8">
            We're grateful to our sponsors who make our community initiatives possible
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {sponsors.map((sponsor, index) => (
              <div key={index} className="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-300">
                <div className="w-16 h-16 bg-gradient-to-br from-gray-300 to-gray-400 rounded-lg mx-auto mb-3 flex items-center justify-center">
                  <span className="text-white text-sm font-bold">
                    {sponsor.split(' ').map(word => word[0]).join('')}
                  </span>
                </div>
                <p className="text-gray-700 font-medium text-sm">{sponsor}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default AboutUs


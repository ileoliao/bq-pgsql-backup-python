import { Calendar, Video } from 'lucide-react'
import { Button } from '@/components/ui/button'

const AITuesdays = () => {
  return (
    <section id="ai-tuesdays" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">AI Tuesdays</h2>
          <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Join our weekly AI Tuesdays sessions where we explore the latest developments in artificial intelligence, 
              share insights, and build a stronger AI community. Every Tuesday, we bring together AI enthusiasts, 
              professionals, and learners to discuss trending topics, showcase innovative projects, and network with 
              like-minded individuals.
            </p>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Whether you're a beginner looking to learn about AI or an expert wanting to share your knowledge, 
              AI Tuesdays provides the perfect platform for growth and collaboration.
            </p>
          </div>

          <div className="space-y-4">
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border border-blue-200">
              <div className="flex items-center mb-4">
                <Calendar className="h-6 w-6 text-blue-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Join Our Meetup</h3>
              </div>
              <p className="text-gray-700 mb-4">
                Connect with our community and stay updated on upcoming AI Tuesday sessions.
              </p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                AI Tuesdays Meetup
              </Button>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-lg border border-purple-200">
              <div className="flex items-center mb-4">
                <Video className="h-6 w-6 text-purple-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Session Recordings</h3>
              </div>
              <p className="text-gray-700 mb-4">
                Access our archive of past AI Tuesday sessions and catch up on missed content.
              </p>
              <Button className="w-full bg-purple-600 hover:bg-purple-700">
                History Session Recordings
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default AITuesdays


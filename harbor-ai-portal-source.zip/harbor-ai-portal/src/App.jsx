import Navigation from './components/layout/Navigation'
import PromotionBanner from './components/layout/PromotionBanner'
import Footer from './components/layout/Footer'
import AITuesdays from './components/sections/AITuesdays'
import TrainingPathways from './components/sections/TrainingPathways'
import AIUseCases from './components/sections/AIUseCases'
import CommunityStories from './components/sections/CommunityStories'
import AboutUs from './components/sections/AboutUs'
import Links from './components/sections/Links'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <PromotionBanner />
      
      <main>
        <AITuesdays />
        <TrainingPathways />
        <AIUseCases />
        <CommunityStories />
        <AboutUs />
        <Links />
      </main>
      
      <Footer />
    </div>
  )
}

export default App

